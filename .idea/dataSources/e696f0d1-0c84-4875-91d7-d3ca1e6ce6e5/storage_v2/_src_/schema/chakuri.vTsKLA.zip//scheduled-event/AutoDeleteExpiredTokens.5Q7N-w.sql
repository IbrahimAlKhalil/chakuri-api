create definer = root@localhost event AutoDeleteExpiredTokens on schedule
    every '5' HOUR
        starts '2019-11-27 18:03:17'
    on completion preserve
    enable
    do
    DELETE FROM chakuri.tokens WHERE updated_at < DATE_SUB(NOW(), INTERVAL 5 HOUR);

