create definer = root@localhost event AutoDeleteExpiredVerificationTokens on schedule
  every '1' HOUR
    starts '2019-07-31 18:19:12'
  on completion preserve
  enable
  do
  DELETE FROM chakuri.verification_tokens WHERE updated_at < DATE_SUB(NOW(), INTERVAL 1 HOUR);

