create definer = root@localhost event AutoDeleteExpiredVerificationTokens on schedule
    every '1' HOUR
        starts '2019-12-03 00:00:00'
    on completion preserve
    enable
    do
    DELETE FROM chakuri.verification_tokens WHERE auto_delete = 1 and created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR);

