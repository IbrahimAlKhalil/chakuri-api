create definer = root@localhost event AutoDeleteExpiredVerificationTokens on schedule
  at '2019-10-03 11:52:44'
  on completion preserve
  disable
  do
  DELETE FROM chakuri.verification_tokens WHERE auto_delete = 1 and created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR);

