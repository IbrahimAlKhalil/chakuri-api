create definer = root@localhost event AutoDeleteExpiredTokens on schedule
  every '5' HOUR
    starts '2019-07-21 00:00:00'
  on completion preserve
  enable
  do
  DELETE FROM chakuri.tokens WHERE updated_at < DATE_SUB(NOW(), INTERVAL 5 HOUR);

