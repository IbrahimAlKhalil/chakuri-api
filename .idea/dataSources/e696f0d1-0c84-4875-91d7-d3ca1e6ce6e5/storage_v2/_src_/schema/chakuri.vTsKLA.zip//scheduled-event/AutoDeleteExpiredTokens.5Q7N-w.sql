create definer = root@localhost event AutoDeleteExpiredTokens on schedule
  at '2019-10-04 10:52:44'
  on completion preserve
  disable
  do
  DELETE FROM chakuri.tokens WHERE updated_at < DATE_SUB(NOW(), INTERVAL 5 HOUR);

